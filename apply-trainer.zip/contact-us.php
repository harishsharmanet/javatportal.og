
<!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <link rel="shortcut icon" href="assets/img/favicon.ico" />
        <meta name="viewport" content="width=device-width">
        <title>Contact Us - JavaTportal Corporation Private Limited</title>
    <meta name="description" content="JavaTportal leading Website Designing Company in Ghaziabad based Company. Which Offers Website Designing, Mobile Apps Development, Digital Marketing, Ecommerce software Services.">
<meta name="keywords" content="website designing company in delhi,web designing company in delhi,web designing company delhi,website designing company delhi,website designing in delhi,website designing company in noida,best website designing company in delhi,ecommerce website designing company in delhi,top web designing company in delhi,website designing services in delhi,responsive website designing company in delhi,web designing company, website designing companies, web development companies, website designing in India,B2B Portal Development Company Delhi, B2C Portal Development company Delhi" />
  <meta name="copyright" content="Copyright 2014-17 JavaTportal Corporation (P) Limited - Website Designing Company in Ghaziabad" /> 
 <!--[if IE]> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <![endif]-->
    	<meta name="author" content=" javatportal.org"/>
	<meta name="rating" CONTENT="General"/>
	<meta name="revisit-after" CONTENT="2 days">
	<meta name="robots" content=" ALL, index, follow"/>
	<meta <meta name="distribution" content="Global" />
	<meta name="rating" content="Safe ForAll" />
	<meta name="language" content="English" />
	<meta http-equiv="window-target" content="_top"/>
	<meta http-equiv="pics-label" content="for all ages"/>
	<meta name="contact City" content=" Noida, Madhapur, Attapur, Hi Tech City, Gachibowli, India, Bangalore, USA, UAE, Mumbai, Delhi, Chennai, India, Lucknow, Kolkata "/>
	<meta name="subject" CONTENT=" Website Designing in Noida | Mobile Apps Development in Noida "/>
	<meta property="og:locale" content="en  US" />
	<meta property="og: title" content ="Website Designing in Ghaziabad | Mobile Apps Development in Ghaziabad" />
	<meta property="og: description" content= "	JavaTportal leading Website Designing Company in Ghaziabad based Company. Which Offers Web Designing, Mobile Apps Development, Digital Marketing, Ecommerce software Services "/>
	<meta property="og:url" content="javatportal.org " />
	<meta property="og:site name" content=" JavaTportal Corporation " />
	<meta name="rating" content="general"/>
	<link rel="canonical" href=" http://www.javatportal.org/" />
	<meta content="All, FOLLOW" name="GOOGLEBOTS"/>
	<meta content="All, FOLLOW" name="YAHOOBOTS"/>
	<meta content="All, FOLLOW" name="MSNBOTS"/>
	<meta content="All, FOLLOW" name="BINGBOTS"/>
	<meta content="all" name="Google bot -Image"/>
	<meta content="ALL" name="WEBCRAWLERS"/>
	
 <meta name="twitter:card" content="summary" />
<meta name="twitter:description"  content= "JavaTportal leading Website Designing Company in Ghaziabad based Company. Which Offers Web Designing, Mobile Apps Development, Digital Marketing, Ecommerce software Services "/>
<meta name="twitter:title" content="Website Designing in Ghaziabad | Mobile Apps Development in Ghaziabad" />

        <?php include 'styling.php';?>
        <style>
            h1, h2, h3, h4, h5, h6 
            {
                text-align: center !important;
            }
            .row .col{
                text-align:center;
            }
        </style>
        <title></title>
    </head>
    <body>
        <?php include 'inc/header.php';?>
        <div class="jumbotron">
        <h1 class="display-3">Contact Us</h1>
        <h4>We are Happy to Serve You</h4>
        </div>
        <div class="container">
            <h2>Javatportal Corporation - Website/Software Development and Training Center</h2>
            <h5>FF-18 Mark Mall Vasundhara, Sector 4B, Vasundhara, Ghaziabad, Uttar Pradesh 201012</h5>
            
            <div class="row">
                <div class="col">
                    <i class="fas fa-phone fa-7x faa-wrench animated"></i><br/><br/>
                    <h2><a href="tel:09711195889">+91 | 97111 95889 | 9650322998</a></h2>
                </div>
                <div class="col">
                     <i class="fas fa-at fa-7x faa-horizontal animated"></i><br/><br/>
                     <h2 style="text-transform: inherit;"><a href="mailto:info@javatportal.org?Subject=Enquiry%20Statement" target="_top">info@javatportal.org</a></h2>
                    
                </div>
            </div>
            


        
        
        </div>
        <?php include 'inc/footer.php'; ?>
   