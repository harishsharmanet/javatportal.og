<?php include 'inc/config.php'; ?>
<base href="http://localhost/javatportal.org/">

<link rel="stylesheet" href="assets/css/jtpcoursestyle.css">
<link rel="stylesheet" href="assets/css/cbdesign.css">
 <link rel="stylesheet" href="assets/css/front-ui.css">
<link rel="stylesheet" href="assets/css/allcourses.css">
 <link rel="stylesheet" href="assets/css/custom.css">
<link rel="stylesheet" href="assets/css/bootstrap22.min.css">
<link rel="stylesheet" href="assets/css/carasoul.css">
 <link rel="stylesheet" href="assets/css/font-awesome-animation.min.css">
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
 <script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>

