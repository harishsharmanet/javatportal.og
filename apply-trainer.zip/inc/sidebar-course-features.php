
<!-- Course Features -->

<div class="course-features">
    <h3 class="qbheading">Here Are A Few Things To Keep In Mind</h3>
    <div class="features-content">
        <div class="features">
            <span class="ficon">
                <i class="fas fa-desktop"></i>
            </span>
            Accredited Training Partner
        </div>
        <div class="features">
            <span class="ficon">
                <i class="far fa-clipboard"></i>
            </span>
            Multiple Training Delivery 
        </div>
        <div class="features">
            <span class="ficon">
                <i class="far fa-clipboard"></i>
            </span>
            Online Live Assignments
        </div>
        <div class="features">
            <span class="ficon">
                <i class="fas fa-stopwatch"></i>
            </span>
            Lifetime Expert Support
        </div>
        <div class="features">
            <span class="ficon">
                <i class="fas fa-headphones"></i>
            </span>
            24/7 e-Learning Access 
        </div>
        <div class="features">
            <span class="ficon">
                <i class="fas fa-certificate"></i>
            </span>
            Advance Analytical Reports
        </div>
        <div class="features">
            <span class="ficon">
                <i class="fas fa-globe"></i>
            </span>
            Placement Assistance
        </div>
    </div>
</div>
