<?php


if (!defined('HOME')) define('HOME', 'http://localhost/javatportal.org');
//define("SERVER", "localhost");
//define("USER", "root");
//define("PASS", "");
//define("DB", "javatportal");