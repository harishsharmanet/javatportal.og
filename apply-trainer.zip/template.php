
<!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <link rel="shortcut icon" href="assets/img/favicon.ico" />
        <meta name="viewport" content="width=device-width">
        
        <?php include 'inc/styling.php';?>
        <style>
            h1, h2, h3, h4, h5, h6 
            {
                text-align: center !important;
            }
            .row .col{
                text-align:center;
            }
        </style>
        <title></title>
    </head>
    <body>
        <?php include 'inc/header.php';?>
        <div class="jumbotron">
        <h1 class="display-3">About Us</h1>
        </div>
        
        <?php include 'inc/footer.php'; ?>
    </body>
</html>
